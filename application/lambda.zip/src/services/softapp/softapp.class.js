const { Service } = require('feathers-sequelize');

exports.Softapp = class Softapp extends Service {
  
};
